export { default } from './CardTitle'
